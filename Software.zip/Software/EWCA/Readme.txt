* EWCA is written in Python2.
Programs/packages you must have:
1.	Python2 (available at http://python.org/)
=============
From the commandline write the following commands:

$ python script_main.py -f [fileinteractions] -s [structuralsimilarity]";

-f = the files contains the protein interactions.
-ss = structural similarity (defalt 0.4).

For example, it runs as follows:
python script_main.py -f DIP.txt -s 0.4