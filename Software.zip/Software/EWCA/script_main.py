from optparse import OptionParser
import os


def main():
    print "Starting EWCA ... please wait .."
    parser1 = OptionParser(description='identifies proteins from the PPI network.txt using EWCA method')
    parser1.add_option ('-f', '--fileinteractions', default = 'nofileselected.txt',
                        help="please input protein-protein interactions network")
    parser1.add_option ('-s', '--structuralsimilarity', default = 0.4,
                        help="add neighbor proteins whose conenctions to seed protein above this value to the preliminary complex core, default is 0.4")
    options, args = parser1.parse_args()
    import EWCA
    EWCA.main(options)

if __name__ == "__main__":
    main()